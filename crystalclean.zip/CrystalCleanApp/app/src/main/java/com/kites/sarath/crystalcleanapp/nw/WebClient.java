package com.kites.sarath.crystalcleanapp.nw;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by sarath on 8/12/15.
 */
public class WebClient {

    public static String get(String u){
        String reply="";
        try {
            System.out.println("URL>>"+u);
            URL url = new URL(u);
            URLConnection uc = url.openConnection();
            InputStream in = uc.getInputStream();
            int ch =0;
            while((ch = in.read())!=-1){
                reply+=(char)ch;
            }
            in.close();
        }catch(Exception e){
            System.out.println("Get Url Err>>"+e);
        }
        reply=reply.trim();
        System.out.println("Reply="+reply+"**");
        return reply;
    }
}
