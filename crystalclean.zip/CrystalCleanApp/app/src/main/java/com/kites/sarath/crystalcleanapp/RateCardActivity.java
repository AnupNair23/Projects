package com.kites.sarath.crystalcleanapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.tables.Rate_Settings;
import com.kites.sarath.crystalcleanapp.util.Variables;

import java.util.ArrayList;

public class RateCardActivity extends AppCompatActivity {

    ListView listView=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_card);
        Variables.setThreadPolicy();
        listView = (ListView)findViewById(R.id.listView);
        initList();
    }

    public void initList(){
        String u = Variables.rate_list;
        String reply = WebClient.get(u);
        String st[]= reply.split(";");
        Variables.rsList =new ArrayList<Rate_Settings>();
        ArrayList<String> items = new ArrayList<String>();
        for(int i=0;i<st.length;i++){
            String stt[]=st[i].split("#");
            int id = Integer.parseInt(stt[0].trim());
            String name = stt[1];
            double rate = Double.parseDouble(stt[2].trim());
            Rate_Settings rs = new Rate_Settings(id,name,rate);
            items.add(id+". "+name+" : "+rate+"/-");
            Variables.rsList.add(rs);
        }

        ArrayAdapter aa =new ArrayAdapter(this,android.R.layout.simple_list_item_1,items);
        listView.setAdapter(aa);
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        finish();
    }
}
