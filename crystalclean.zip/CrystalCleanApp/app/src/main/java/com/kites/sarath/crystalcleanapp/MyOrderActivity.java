package com.kites.sarath.crystalcleanapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.tables.Laundry_Details;
import com.kites.sarath.crystalcleanapp.tables.Laundry_Order;
import com.kites.sarath.crystalcleanapp.util.Variables;

import java.util.ArrayList;
import java.util.List;

public class MyOrderActivity extends AppCompatActivity {

    ListView lv =null;
    ArrayList<String> items =new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);
        Variables.setThreadPolicy();

        lv = (ListView)findViewById(R.id.lv);
        initList();
        lv.setOnItemClickListener(new ListClick());
    }

    public void initList(){
        Variables.ldList = new ArrayList<Laundry_Details>();
        Variables.loList = new ArrayList<Laundry_Order>();
        items =new ArrayList<String>();
        items.add("New Order");

        String u = Variables.my_orders+"?user_id="+Variables.userDetails.id;
        String reply = WebClient.get(u);
        String st[]= reply.split(";");
        for(int i=0;i<st.length;i++){
           // System.out.println("st["+i+"]>>>"+st[i]);
            String stt[] = st[i].split("#");
           // System.out.println("Stt Length>>"+stt.length);
            if(stt.length==14) {
                int id = Integer.parseInt(stt[0].trim());
                int user_id = Integer.parseInt(stt[1].trim());
                String pickup_dt = stt[2];
                String pickup_tm = stt[3];
                String delivery_dt = stt[4];
                String delivery_tm = stt[5];
                String addr = stt[6];
                String lat = stt[7];
                String lng = stt[8];
                String remark = stt[9];
                String status = stt[10];
                String dt = stt[11];

                int laundry_id = id;
                double rate = Double.parseDouble(stt[12].trim());
                int qty = Integer.parseInt(stt[13].trim());

                Laundry_Details ld = new Laundry_Details(id, laundry_id, rate, qty);
                Laundry_Order lo = new Laundry_Order(id, user_id, pickup_dt, pickup_tm, delivery_dt, delivery_tm, addr, lat, lng, remark, status, dt);
                Variables.ldList.add(ld);
                Variables.loList.add(lo);
                items.add(dt+"(No.Items:"+qty+")");//pickup_dt + ":" + pickup_tm + "," + delivery_dt + ":" + delivery_tm);
            }
        }
        ArrayAdapter<String> aa =new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,items);
        lv.setAdapter(aa);
    }
    public void pln(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() { public void onClick(DialogInterface dlg, int id) { } }
                ).show();
    }
    public void detailsOrder(final String msg){
        new AlertDialog.Builder(this)
                .setTitle("Order Details")
                .setMessage(msg)
                .setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dlg, int id) {
                                // finish();
                            }
                        }
                )
                .show();
    }
    public void cancelOrder(final int pos,final String msg){
        new AlertDialog.Builder(this)
                .setTitle("Order Details")
                .setMessage(msg)
                .setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dlg, int id) {
                                // finish();
                            }
                        }
                )
                .setNegativeButton(
                        "Cancel Order",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dlg, int id) {

                                Laundry_Order lo = Variables.loList.get(pos);
                                if (lo.status.equals("done")) {
                                    pln("Order Cancellation", "Invalid");

                                } else {
                                    String u = Variables.cancel_order + "?id=" + lo.id;
                                    String reply = WebClient.get(u);
                                    pln("Order Cancellation", reply);
                                    initList();
                                }
                            }
                        }
                ).show();
    }
    public class ListClick implements ListView.OnItemClickListener{

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            if(i==0){
               // pln("New Order","Place A New Order");
                Intent in =new Intent(MyOrderActivity.this,NewOrderActivity.class);
                startActivity(in);
                finish();
            }
            else{
                Laundry_Order lo =Variables.loList.get(i-1);
                Laundry_Details ld = Variables.ldList.get(i-1);
                if (lo.status.equals("done")) {

                    detailsOrder("Status: " + lo.status + "\nRate: " + ld.rate + "\n Quantity: " + ld.qty);
                }
                else {
                    cancelOrder(i - 1, "Status: " + lo.status + "\nRate: " + ld.rate + "\n Quantity: " + ld.qty);
                }
            }
        }
    }



}
