package com.kites.sarath.crystalcleanapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.util.Variables;

public class RegisterActivity extends AppCompatActivity {

    public EditText nameET,mobileET,emailET,passwdET;
    public Button registerBT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Variables.setThreadPolicy();

        nameET = (EditText)findViewById(R.id.nameET);
        mobileET = (EditText)findViewById(R.id.mobileET);
        emailET = (EditText)findViewById(R.id.emailET);
        passwdET = (EditText)findViewById(R.id.passwdET);

        registerBT = (Button)findViewById(R.id.registerBT);
        registerBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = nameET.getText().toString();
                String mobile = mobileET.getText().toString();
                String email = emailET.getText().toString();
                String passwd = passwdET.getText().toString();
                if(name.length()==0){
                    pln("Registration Error","Invalid Name");
                    return;
                }
                if(mobile.length()<10){
                    pln("Registration Error","Invalid Mobile");
                    return;
                }
                if(email.length()==0){
                    pln("Registration Error","Invalid Email");
                    return;
                }
                if(passwd.length()<8){
                    pln("Registration Error","Invalid Password min length 8");
                    return;
                }
                String u = Variables.user_registration+"?name="+name+"&mobile="+mobile+"&email="+email+"&passwd="+passwd;
                String reply = WebClient.get(u);
                pln("Registration",reply);
                clear();
            }
        });
    }

    public void clear(){
        nameET.setText("");
        mobileET.setText("");
        emailET.setText("");
        passwdET.setText("");
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Intent in = new Intent(RegisterActivity.this,MainActivity.class);
        startActivity(in);
        finish();
    }


    public void pln(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dlg, int id) {
                                Intent in = new Intent(RegisterActivity.this,MainActivity.class);
                                startActivity(in);
                                finish();
                            } }
                ).show();
    }
}
