package com.kites.sarath.crystalcleanapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.util.Variables;

public class ChangePasswordActivity extends AppCompatActivity {

    EditText opasswdET,npasswdET,cpasswdET;
    Button changeBT,clearBT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        Variables.setThreadPolicy();

        opasswdET = (EditText)findViewById(R.id.opasswdET);
        npasswdET = (EditText)findViewById(R.id.npasswdET);
        cpasswdET = (EditText)findViewById(R.id.cpasswdET);

        changeBT = (Button)findViewById(R.id.changeBT);
        clearBT = (Button)findViewById(R.id.clearBT);

        changeBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String uname = Variables.userDetails.email;
                String opasswd = opasswdET.getText().toString();
                String npasswd = npasswdET.getText().toString();
                String cpasswd = cpasswdET.getText().toString();

                if(opasswd.length()==0){
                    pln("Password Error","Invalid Old Password");
                    return;
                }
                if(npasswd.length()==0){
                    pln("Password Error","Invalid New Password");
                    return;
                }
                if(cpasswd.length()==0){
                    pln("Password Error","Invalid Confirm Password");
                    return;
                }

                if(npasswd.equals(cpasswd)){
                    String u = Variables.user_changepassword+"?uname="+uname+"&opasswd="+opasswd+"&npasswd="+npasswd;
                    String reply = WebClient.get(u);
                    pln("Password Change",reply);
                }
                else{
                    pln("Error","New and Confirm Password do not match");
                    clear();
                }
            }
        });
        clearBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
            }
        });
    }
    public void clear(){
        opasswdET.setText("");
        npasswdET.setText("");
        cpasswdET.setText("");
    }
    public void pln(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() { public void onClick(DialogInterface dlg, int id) { } }
                ).show();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        finish();
    }
}
