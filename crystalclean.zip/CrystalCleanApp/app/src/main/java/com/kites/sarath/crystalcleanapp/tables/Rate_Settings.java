/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kites.sarath.crystalcleanapp.tables;

/**
 *
 * @author sarath
 */
public class Rate_Settings {
    /*
    rate_settings,id,name,rate
    */
    public int id;
    public String name;
    public double rate;

    public Rate_Settings(int id, String name, double rate) {
        this.id = id;
        this.name = name;
        this.rate = rate;
    }

    @Override
    public String toString() {
        return id + "," + name + "," + rate;
    }
    
    public String toString2() {
        return "Rate_Settings{" + "id=" + id + ", name=" + name + ", rate=" + rate + '}';
    }
    
}
