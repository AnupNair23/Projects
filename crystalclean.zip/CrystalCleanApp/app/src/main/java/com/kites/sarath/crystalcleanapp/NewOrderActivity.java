package com.kites.sarath.crystalcleanapp;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.tables.Rate_Settings;
import com.kites.sarath.crystalcleanapp.util.Variables;

import java.util.ArrayList;
import java.util.Calendar;

public class NewOrderActivity extends AppCompatActivity {

    EditText pdateET,ptimeET,ddateET,dtimeET;
    Button addBT,nextBT,clearBT;
    EditText addrET,rateET,qtyET;
    private int mYear, mMonth, mDay, mHour, mMinute;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_order);
        Variables.setThreadPolicy();
        pdateET = (EditText)findViewById(R.id.pdateET);
        ptimeET = (EditText)findViewById(R.id.ptimeET);
        ddateET = (EditText)findViewById(R.id.ddateET);
        dtimeET = (EditText)findViewById(R.id.dtimeET);

        addrET = (EditText)findViewById(R.id.addrET);
        rateET = (EditText)findViewById(R.id.rateET);
        qtyET = (EditText)findViewById(R.id.qtyET);

        addBT = (Button)findViewById(R.id.addBT);
        nextBT = (Button)findViewById(R.id.nextBT);
        clearBT = (Button)findViewById(R.id.clearBT);

        pdateET.setOnClickListener(new EditText.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickDate1(view);
            }
        });
        ptimeET.setOnClickListener(new EditText.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickTime1(view);
            }
        });

        ddateET.setOnClickListener(new EditText.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickDate2(view);
            }
        });
        dtimeET.setOnClickListener(new EditText.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickTime2(view);
            }
        });

        addBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showPopup();
            }
        });
        clearBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clear();
            }
        });
        nextBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int user_id = Variables.userDetails.id;
                String pickup_dt = pdateET.getText().toString();
                String pickup_tm = ptimeET.getText().toString();
                String delivery_dt = ddateET.getText().toString();
                String delivery_tm = dtimeET.getText().toString();
                String addr =addrET.getText().toString();
                addr = addr.replace(' ','+');
                String lat = ""+Variables.lat;
                String lng = ""+Variables.lng;
                String remark = "remark";
                String rate = Variables.totalRate+"";
                String qty =  Variables.totalQty+"";

                if(pickup_dt.length()==0){
                    pln("Order Error","Invalid Pickup Date");
                    return;
                }
                if(pickup_tm.length()==0){
                    pln("Order Error","Invalid Pickup Time");
                    return;
                }
                if(delivery_dt.length()==0){
                    pln("Order Error","Invalid Delivery Date");
                    return;
                }
                if(delivery_tm.length()==0){
                    pln("Order Error","Invalid Delivery Time");
                    return;
                }
                if(addr.length()==0){
                    pln("Order Error","Invalid Address");
                    return;
                }
                if(Variables.totalRate==0){
                    pln("Order Error","Sorry Basket Is Empty");
                    return;
                }
                if(Variables.totalQty==0){
                    pln("Order Error","Sorry Basket Is Empty");
                    return;
                }
                String u = Variables.register_order+"?user_id="+user_id+"&pickup_dt="+pickup_dt+"&pickup_tm="+pickup_tm+"&delivery_dt="+delivery_dt+"&delivery_tm="+delivery_tm+"&addr="+addr+"&lat="+lat+"&lng="+lng+"&remark="+remark+"&rate="+rate+"&qty="+qty;
                String reply = WebClient.get(u);
                pln("Order",reply);
                clear();
               // pln("Feature", "Not Active");
              //  Intent in = new Intent(NewOrderActivity.this,PaymentActivity.class);
               // startActivity(in);
            }
        });
    }

    public void pickDate1(View v){
        // Process to get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // Launch Date Picker Dialog
        DatePickerDialog dpd = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) {
                        // Display Selected date in textbox
                        mMonth = monthOfYear;
                        mDay = dayOfMonth;
                        mYear = year;
                        pdateET.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                }, mYear, mMonth, mDay);
        dpd.show();
    }
    public void pickTime1(View v){
        // Process to get Current Time
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog tpd = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay,int minute) {
                // Display Selected time in textbox
                mHour = hourOfDay;
                mMinute = minute;
                ptimeET.setText(hourOfDay + ":" + minute);
            }
        }, mHour, mMinute, false);
        tpd.show();
    }
    public void pickDate2(View v){
        // Process to get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // Launch Date Picker Dialog
        DatePickerDialog dpd = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) {
                        // Display Selected date in textbox
                        mMonth = monthOfYear;
                        mDay = dayOfMonth;
                        mYear = year;
                        ddateET.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                }, mYear, mMonth, mDay);
        dpd.show();
    }
    public void pickTime2(View v){
        // Process to get Current Time
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        // Launch Time Picker Dialog
        TimePickerDialog tpd = new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker view, int hourOfDay,int minute) {
                // Display Selected time in textbox
                mHour = hourOfDay;
                mMinute = minute;
                dtimeET.setText(hourOfDay + ":" + minute);
            }
        }, mHour, mMinute, false);
        tpd.show();
    }
    public void initList(Spinner spin){
        String u = Variables.rate_list;
        String reply = WebClient.get(u);
        String st[]= reply.split(";");
        Variables.rsList =new ArrayList<Rate_Settings>();
        ArrayList<String> items = new ArrayList<String>();
        for(int i=0;i<st.length;i++){
            String stt[]=st[i].split("#");
            int id = Integer.parseInt(stt[0].trim());
            String name = stt[1];
            double rate = Double.parseDouble(stt[2].trim());
            Rate_Settings rs = new Rate_Settings(id,name,rate);
            items.add(id+". "+name+" ("+rate+")");
            Variables.rsList.add(rs);
        }

        ArrayAdapter<String> aa= new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                items);
        aa.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spin.setAdapter(aa);
    }

    public void showPopup(){
        View view = getLayoutInflater().inflate(R.layout.add_basket, null);


        final AlertDialog dialog =  new AlertDialog.Builder(this).setView(view).create();
        dialog.show();
        final Spinner spin = (Spinner)view.findViewById(R.id.spin);
        initList(spin);
        final EditText qty = (EditText)view.findViewById(R.id.qtyET);
        Button okbtn = (Button) view.findViewById(R.id.okBT);

        okbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                int pos = spin.getSelectedItemPosition();
                double rate = Variables.rsList.get(pos).rate;
                int q = Integer.parseInt(qty.getText().toString());
                Variables.totalRate += (q*rate);
                Variables.totalQty+=Integer.parseInt(qty.getText().toString());

                qtyET.setText("Qty: "+Variables.totalQty);
                rateET.setText("Rate: "+Variables.totalRate);
                dialog.dismiss();
            }
        });
        Button resetbtn = (Button) view.findViewById(R.id.resetBT);

        resetbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                Variables.totalQty=0;
                Variables.totalRate=0.0;

                qtyET.setText("Qty: "+Variables.totalQty);
                rateET.setText("Rate: "+Variables.totalRate);
                dialog.dismiss();
            }
        });
    }

    public void pln(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() { public void onClick(DialogInterface dlg, int id) { } }
                ).show();
    }
    public void clear(){
        pdateET.setText("");
        ptimeET.setText("");
        ddateET.setText("");
        dtimeET.setText("");
        addrET.setText("");
        rateET.setText("");
        qtyET.setText("");
        Variables.totalQty=0;
        Variables.totalRate=0.0;
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Intent in = new Intent(NewOrderActivity.this,MyOrderActivity.class);
        startActivity(in);
        finish();
    }
}
