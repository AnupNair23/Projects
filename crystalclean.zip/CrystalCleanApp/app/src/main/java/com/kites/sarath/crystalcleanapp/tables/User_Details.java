/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kites.sarath.crystalcleanapp.tables;

/**
 *
 * @author sarath
 */
public class User_Details {
    /*
    user_details,id,name,mobile,email,dt,status
    */
    public int id;
    public String name,mobile,email,dt,status;

    public User_Details(int id, String name, String mobile, String email, String dt, String status) {
        this.id = id;
        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.dt = dt;
        this.status = status;
    }

    @Override
    public String toString() {
        return id + "," + name + "," + mobile + "," + email + "," + dt + "," + status;
    }
    public String toString2() {
        return "User_Details{" + "id=" + id + ", name=" + name + ", mobile=" + mobile + ", email=" + email + ", dt=" + dt + ", status=" + status + '}';
    }
    
}
