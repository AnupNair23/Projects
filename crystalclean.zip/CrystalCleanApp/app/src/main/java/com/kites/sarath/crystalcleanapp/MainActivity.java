package com.kites.sarath.crystalcleanapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.tables.User_Login;
import com.kites.sarath.crystalcleanapp.util.Variables;

public class MainActivity extends AppCompatActivity {

    Button loginBT,exitBT,registerBT;
    EditText unameET,passwdET;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Variables.setThreadPolicy();
        loginBT = (Button)findViewById(R.id.loginBT);
        registerBT = (Button)findViewById(R.id.registerBT);
        exitBT = (Button)findViewById(R.id.exitBT);

        unameET = (EditText)findViewById(R.id.unameET);
        passwdET = (EditText)findViewById(R.id.passwdET);

        loginBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String uname= unameET.getText().toString();
                String passwd = passwdET.getText().toString();
                if(uname.length()==0){
                    pln("Login Error","Invalid Username");
                    return;
                }
                if(passwd.length()==0){
                    pln("Login Error","Invalid Password");
                    return;
                }
                String u = Variables.user_login+"?uname="+uname+"&passwd="+passwd;
                String result = WebClient.get(u);
                String st[]= result.split("#");
                int id = Integer.parseInt(st[0].trim());
                uname = st[1];
                passwd = st[2];
                if(id==0){
                    pln("Login Error","Invalid Username or Password");
                    clear();
                }
                else {
                    Variables.userLogin = new User_Login(id,uname,passwd);
                    Intent in = new Intent(MainActivity.this, HomeActivity.class);
                    startActivity(in);
                    finish();
                }
            }
        });

        registerBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent in = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(in);
                finish();
            }
        });
        exitBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        pln("Exit","Use Exit Button");
    }

    public void pln(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() { public void onClick(DialogInterface dlg, int id) { } }
                ).show();
    }
    public void clear(){
        unameET.setText("");
        passwdET.setText("");
    }

}
