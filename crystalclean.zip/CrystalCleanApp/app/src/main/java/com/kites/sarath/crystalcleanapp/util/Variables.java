package com.kites.sarath.crystalcleanapp.util;

import android.os.Build;
import android.os.StrictMode;

import com.kites.sarath.crystalcleanapp.tables.Laundry_Details;
import com.kites.sarath.crystalcleanapp.tables.Laundry_Order;
import com.kites.sarath.crystalcleanapp.tables.Rate_Settings;
import com.kites.sarath.crystalcleanapp.tables.User_Details;
import com.kites.sarath.crystalcleanapp.tables.User_Login;

import java.util.ArrayList;

/**
 * Created by sarath on 23/3/16.
 */
public class Variables {
    public static String serverIP = "192.168.1.20";
    public static String serverURL = "http://"+serverIP+":8084/CrystalCleanServer/android/";
    public static String my_address = serverURL+"my_address.jsp";
    public static String my_orders = serverURL+"my_orders.jsp";
    public static String my_payments = serverURL+"my_payments.jsp";
    public static String order_status = serverURL+"order_status.jsp";
    public static String rate_list = serverURL+"rate_list.jsp";
    public static String register_order = serverURL+"register_order.jsp";
    public static String user_details = serverURL+"user_details.jsp";
    public static String user_login = serverURL+"user_login.jsp";
    public static String user_payment = serverURL+"user_payment.jsp";
    public static String user_registration = serverURL+"user_registration.jsp";
    public static String cancel_order = serverURL+"cancel_order.jsp";
    public static String user_changepassword = serverURL+"user_changepassword.jsp";

    public static void setThreadPolicy(){
        if (Build.VERSION.SDK_INT >= 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }
    public static double totalRate = 0.0;
    public static int totalQty = 0;


    public static User_Login userLogin = null;
    public static User_Details userDetails = null;
    public static ArrayList<Rate_Settings> rsList =new ArrayList<Rate_Settings>();
    public static ArrayList<Laundry_Details> ldList =new ArrayList<Laundry_Details>();
    public static ArrayList<Laundry_Order> loList =new ArrayList<Laundry_Order>();

    public static double lat = 0.0;
    public static double lng = 0.0;



}
