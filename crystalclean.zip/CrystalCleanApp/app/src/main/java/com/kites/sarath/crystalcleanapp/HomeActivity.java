package com.kites.sarath.crystalcleanapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.kites.sarath.crystalcleanapp.nw.WebClient;
import com.kites.sarath.crystalcleanapp.tables.User_Details;
import com.kites.sarath.crystalcleanapp.util.Variables;

public class HomeActivity extends AppCompatActivity {

    Button rateBT,exitBT,profileBT,myorderBT,changeBT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Variables.setThreadPolicy();




        profileBT = (Button)findViewById(R.id.profileBT);
        changeBT = (Button)findViewById(R.id.changeBT);
        rateBT = (Button)findViewById(R.id.rateBT);
        myorderBT = (Button)findViewById(R.id.myorderBT);
        exitBT = (Button)findViewById(R.id.exitBT);

        profileBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg = "Name: "+Variables.userDetails.name+"\nMobile: "+Variables.userDetails.mobile+"\nEmail: "+Variables.userDetails.email;
                pln("My Profile", msg);
            }
        });
        changeBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(HomeActivity.this,ChangePasswordActivity.class);
                startActivity(in);
            }
        });
        rateBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(HomeActivity.this,RateCardActivity.class);
                startActivity(in);
            }
        });
        myorderBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent in = new Intent(HomeActivity.this,MyOrderActivity.class);
                startActivity(in);
            }
        });
        exitBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        initUser();
        if(!Variables.userDetails.status.equals("active")){
            pln2("Account Deactive","Your Account has been deactivated");
        }

    }
    public void initUser(){
        String u = Variables.user_details+"?id="+Variables.userLogin.id;
        String reply = WebClient.get(u);
        String st[] = reply.split("#");
        int id = Integer.parseInt(st[0].trim());
        String name = st[1];
        String mobile = st[2];
        String email = st[3];
        String dt = st[4];
        String status = st[5];
        Variables.userDetails = new User_Details(id,name,mobile,email,dt,status);

    }
    public void pln2(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() { public void onClick(DialogInterface dlg, int id) {finish(); } }
                ).show();
    }
    public void pln(final String title,final String msg){
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setNeutralButton(
                        "Ok",
                        new DialogInterface.OnClickListener() { public void onClick(DialogInterface dlg, int id) { } }
                ).show();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        pln("Exit","Use Exit Button");
    }
}
