package sms;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;


/**
 *
 * @author sarath
 */
public class SMSSender {

    public String multiNumbers(String... numbers) {
        String reply = "";
        if (numbers.length == 1) {
            reply = numbers[0];
        } else {
            for (int i = 0; i < numbers.length - 1; i++) {
                reply += "\"" + numbers[i] + "\",";
            }
            reply += "\"" + numbers[numbers.length - 1] + "\"";
        }
        return reply;
    }

    public String sendSMS(String message, String number) {
        String flag = "";
        try {
            message=message.replace(" ", "%20");
            String login_name = "1";
            String api_password = "1";
            String ver = "1";
            String type = "1";
            String route = "2";
            String sender = "KITESS";
            String action = "push_sms";

            String data = "{\"message\":\"" + message + "\",\"number\":[" + number + "],\"type\":" + type + ",\"route\":" + route + ",\"sender\":\"" + sender + "\"}";
            System.out.println(data);
            String api_ulr = "http://sms.xpresssms.in/api/api.php?ver=" + ver + "&login_name=" + login_name + "&api_password=" + api_password + "&action=" + action + "&data=" + data;
            URL url = new URL(api_ulr);
            URLConnection uc = url.openConnection();
            InputStream in = uc.getInputStream();
            String msg = "";
            int ch = 0;
            while ((ch = in.read()) != -1) {
                msg += (char) ch;
            }
            in.close();
            flag = msg;
            System.out.println(flag);
            //response.sendRedirect(api_ulr);
        } catch (Exception e) {
            System.out.println("Err>>" + e);
            flag = e + "";
        }
        return flag;
    }

    public static void main(String[] args) {
        SMSSender s = new SMSSender();
        String numbers = s.multiNumbers("9846123662", "9961987657");
        String sms = s.sendSMS("Hello", numbers);
        System.out.println(sms);
        /* sms=s.sendSMS("Hello", "9961987657");
         System.out.println(sms);
         sms=s.sendSMS("Hello", "9961987657");
         System.out.println(sms);
         */
    }
}
