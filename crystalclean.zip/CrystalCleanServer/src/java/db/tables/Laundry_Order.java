/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package db.tables;

/**
 *
 * @author sarath
 */
public class Laundry_Order {
    /*
        laundry_order,id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt
    */
    public int id,user_id;
    public String pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt;

    public Laundry_Order(int id, int user_id, String pickup_dt, String pickup_tm, String delivery_dt, String delivery_tm, String addr, String lat, String lng, String remark, String status, String dt) {
        this.id = id;
        this.user_id = user_id;
        this.pickup_dt = pickup_dt;
        this.pickup_tm = pickup_tm;
        this.delivery_dt = delivery_dt;
        this.delivery_tm = delivery_tm;
        this.addr = addr;
        this.lat = lat;
        this.lng = lng;
        this.remark = remark;
        this.status = status;
        this.dt = dt;
    }

    @Override
    public String toString() {
        return id + "#" + user_id + "#" + pickup_dt + "#" + pickup_tm + "#" + delivery_dt + "#" + delivery_tm + "#" + addr + "#" + lat + "#" + lng + "#" + remark + "#" + status + "#" + dt;
    }
    public String toString2() {
        return "Laundry_Order{" + "id=" + id + ", user_id=" + user_id + ", pickup_dt=" + pickup_dt + ", pickup_tm=" + pickup_tm + ", delivery_dt=" + delivery_dt + ", delivery_tm=" + delivery_tm + ", addr=" + addr + ", lat=" + lat + ", lng=" + lng + ", remark=" + remark + ", status=" + status + ", dt=" + dt + '}';
    }
    
}
