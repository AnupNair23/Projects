/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package db.tables;

/**
 *
 * @author sarath
 */
public class Payment_Details {
    /*
    payment_details,id,user_id,laundry_id,typ,amt,dt
    */
    public int id,user_id,laundry_id;
    public String typ;
    public double amt;
    public String dt;

    public Payment_Details(int id, int user_id, int laundry_id, String typ, double amt, String dt) {
        this.id = id;
        this.user_id = user_id;
        this.laundry_id = laundry_id;
        this.typ = typ;
        this.amt = amt;
        this.dt = dt;
    }

    @Override
    public String toString() {
        return id + "," + user_id + "," + laundry_id + "," + typ + "," + amt + ", dt=" + dt + '}';
    }
    public String toString2() {
        return "Payment_Details{" + "id=" + id + ", user_id=" + user_id + ", laundry_id=" + laundry_id + ", typ=" + typ + ", amt=" + amt + ", dt=" + dt + '}';
    }
    
}
