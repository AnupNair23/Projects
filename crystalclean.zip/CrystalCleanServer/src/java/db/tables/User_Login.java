/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package db.tables;

/**
 *
 * @author sarath
 */
public class User_Login {
    /*
     user_login,id,uname,passwd
    */
    public int id;
    public String uname,passwd;

    public User_Login(int id, String uname, String passwd) {
        this.id = id;
        this.uname = uname;
        this.passwd = passwd;
    }

    @Override
    public String toString() {
        return id + "#" + uname + "#" + passwd;
    }
     public String toString2() {
        return "User_Login{" + "id=" + id + ", uname=" + uname + ", passwd=" + passwd + '}';
    }
    
}
