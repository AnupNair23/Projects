package db;

import java.sql.*;

public class DBCon {

    Connection con = null;
    Statement stmt = null;
    static final String DBPath = "/home/sarath/coding/kites_projects/mini/crystalclean/CrystalCleanServer/out/crystal.db";
   
    
    static final String DBPATH =DBPath;
    static final String DRIVER = "org.sqlite.JDBC";
    static final String CONSTRING = "jdbc:sqlite:"+DBPATH;
    public static String tables[] =  new String[18];
    public DBCon() {

        try {
            Class.forName(DRIVER);
            con = DriverManager.getConnection(CONSTRING);
            System.out.println("Database Created");
            con.setAutoCommit(false);
            stmt = con.createStatement();
            System.out.println("Statement Created");

        } catch (Exception e) {
            System.out.println("DBConn Constructor Err>>" + e);
        }
    }

    public void createTables() {
        try {

            tables[0] = "CREATE TABLE IF NOT EXISTS admin_login("
                    + "id INT,"
                    + "uname VARCHAR(50),"
                    + "passwd VARCHAR(50),"
                    + "status VARCHAR(50))";
                  
            tables[1] = "CREATE TABLE IF NOT EXISTS rate_settings("
                    + "id INT,"
                    + "name VARCHAR(50),"
                    + "rate DOUBLE)";
                   
            tables[2] = "CREATE TABLE IF NOT EXISTS user_details("
                    + "id INT,"
                    + "name VARCHAR(50),"
                    + "mobile VARCHAR(50),"
                    + "email VARCHAR(50),"
                    + "dt VARCHAR(50),"
                    + "status VARCHAR(50))";
            
            tables[3] = "CREATE TABLE IF NOT EXISTS user_login("
                    + "id INT,"
                    + "uname VARCHAR(50),"
                    + "passwd VARCHAR(50))";
                   
            tables[4] = "CREATE TABLE IF NOT EXISTS laundry_order("
                    + "id INT,"
                    + "user_id INT,"
                    + "pickup_dt VARCHAR(50),"
                    + "pickup_tm VARCHAR(50),"
                    + "delivery_dt VARCHAR(50),"
                    + "delivery_tm VARCHAR(50),"
                    + "addr VARCHAR(250),"
                    + "lat VARCHAR(50),"
                    + "lng VARCHAR(50),"
                    + "remark VARCHAR(150),"
                    + "status VARCHAR(50),"
                    + "dt VARCHAR(50))";
            
            tables[5] = "CREATE TABLE IF NOT EXISTS laundry_details("
                    + "id INT,"
                    + "laundry_id INT,"
                    + "rate DOUBLE,"
                    + "qty INT)";
            
             tables[6] = "CREATE TABLE IF NOT EXISTS payment_details("
                    + "id INT,"
                    + "user_id INT,"
                    + "laundry_id INT,"
                    + "typ VARCHAR(50),"
                    + "amt DOUBLE,"
                    + "dt VARCHAR(50))";
                    
            
            for(int i=0;i<tables.length;i++){
                if(tables[i]==null)break;
                int j = executeUpdate(tables[i]);

                if (j > 0) {
                    System.out.println("Table Created");
                }
            }
            
        } catch (Exception e) {
            System.out.println("DBConn Create Tables Err>>" + e);
        }
    }

    public void dropTables() {
        try {
            tables[0] = "DROP TABLE IF EXISTS admin_login";
            tables[1] = "DROP TABLE IF EXISTS rate_settings";
            tables[2] = "DROP TABLE IF EXISTS user_details";
            tables[3] = "DROP TABLE IF EXISTS user_login";
            tables[4] = "DROP TABLE IF EXISTS laundry_order";
            tables[5] = "DROP TABLE IF EXISTS laundry_details";
            tables[5] = "DROP TABLE IF EXISTS laundry_details";
           
            
            for(int i=0;i<tables.length;i++){
                if(tables[i]==null)break;
                int j = executeUpdate(tables[i]);

                if (j > 0) {
                    System.out.println("Table Deleted");
                }
            }
        } catch (Exception e) {
            System.out.println("DBCon Drop Tables Err>>" + e);
        }

    }

    public int executeUpdate(String query) {
        int result = 0;
        try {
            System.out.println("DBCon Query>>" + query);
            result = stmt.executeUpdate(query);
            con.commit();
        } catch (Exception e) {
            System.out.println("DBCon Execute Update Error>>" + e);
        }
        return result;
    }

    public ResultSet executeQuery(String query) {
        ResultSet rset = null;
        try {

            System.out.println("DBCon Query>>" + query);
            con.commit();
            rset = stmt.executeQuery(query);

        } catch (Exception e) {
            System.out.println("DBCon Execute Query Err>>" + e);
        }
        return rset;
    }

    public void close() {
        try {
            con.close();
        } catch (Exception e) {
            System.out.println("DBCon Close Err>>" + e);
        }
    }

    public static void main(String args[]) {
        DBCon dbcon = new DBCon();
        dbcon.createTables();
       // dbcon.dropTables();
        dbcon.close();
    }
}
