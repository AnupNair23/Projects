/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;


import db.tables.Admin_Login;
import db.tables.Laundry_Details;
import db.tables.Laundry_Order;
import db.tables.Payment_Details;
import db.tables.Rate_Settings;
import db.tables.User_Details;
import db.tables.User_Login;
import java.sql.ResultSet;
import java.util.ArrayList;


/**
 *
 * @author root
 */
public class DBProcess extends DBCon{
 
    /******************************************************************/
     /*
     admin_login,id,uname,passwd,status
    */
    public int getMaxID_admin_login(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM admin_login";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxID_admin_login Err>>"+e);
        }
        return mid;
    }

    public int insert_admin_login(Admin_Login obj){
        int result =0;
        try {
            String query="INSERT INTO admin_login(id,uname,passwd,status) VALUES("+obj.id+",'"+obj.uname+"','"+obj.passwd+"','"+obj.status+"')";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("insert_admin_login Err>>"+e);
        }
        return result;
    }
    public int delete_admin_login(int id){
        int result = 0;
        try {
            String query="DELETE FROM admin_login WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("delete_admin_login Err>>"+e);
        }
        return result;
    }
    
    public int update_admin_login(Admin_Login obj){
        int result =0;
        try {
            String query="UPDATE admin_login SET uname='"+obj.uname+"',passwd='"+obj.passwd+"',status='"+obj.status+"' WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_admin_login Err>>"+e);
        }
        return result;
    }
    public int update_admin_login(String uname,String opasswd,String npasswd){
        int result =0;
        try {
            String query="UPDATE admin_login SET passwd='"+npasswd+"' WHERE uname='"+uname+"' AND passwd='"+opasswd+"'";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_admin_login Err>>"+e);
        }
        return result;
    }
    
    public Admin_Login select_admin_login(int id){
        Admin_Login obj =null;
        try {
            String query="SELECT id,uname,passwd,status FROM admin_login WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               String uname = rset.getString("uname");
               String passwd  = rset.getString("passwd");
               String status  = rset.getString("status");
               obj = new Admin_Login(id, uname, passwd, status);
            }
        } catch (Exception e) {
            System.out.println("select_admin_login Err>>"+e);
        }
        return obj;
    }
    public Admin_Login select_admin_login(String uname,String passwd){
        Admin_Login obj =null;
        try {
            String query="SELECT id,uname,passwd,status FROM admin_login WHERE uname='"+uname+"' AND passwd='"+passwd+"'";
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               int id = rset.getInt("id");
               uname = rset.getString("uname");
               passwd  = rset.getString("passwd");
               String status  = rset.getString("status");
               obj = new Admin_Login(id, uname, passwd, status);
            }
        } catch (Exception e) {
            System.out.println("select_admin_login Err>>"+e);
        }
        return obj;
    }
    public ArrayList<Admin_Login> selectAll_admin_login(){
        ArrayList<Admin_Login> objList = new ArrayList<Admin_Login>();
        try {
            String query="SELECT id,uname,passwd,status FROM admin_login ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               String uname = rset.getString("uname");
               String passwd  = rset.getString("passwd");
               String status  = rset.getString("status");
               Admin_Login obj = new Admin_Login(id, uname, passwd, status);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_admin_login Err>>"+e);
        }
        return objList;
    }
   
    
    /******************************************************************/
    /******************************************************************/
    /*
     laundry_details,id,laundry_id,rate,qty
    */
    public int getMaxID_laundry_details(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM laundry_details";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxID_laundry_details Err>>"+e);
        }
        return mid;
    }

    public int insert_laundry_details(Laundry_Details obj){
        int result =0;
        try {
            String query="INSERT INTO laundry_details(id,laundry_id,rate,qty) VALUES("+obj.id+","+obj.laundry_id+","+obj.rate+","+obj.qty+")";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("insert_laundry_details Err>>"+e);
        }
        return result;
    }
    public int delete_laundry_details(int id){
        int result = 0;
        try {
            String query="DELETE FROM laundry_details WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("delete_laundry_details Err>>"+e);
        }
        return result;
    }
    
    public int update_laundry_details(Laundry_Details obj){
        int result =0;
        try {
            String query="UPDATE laundry_details SET laundry_id="+obj.laundry_id+",rate="+obj.rate+",qty="+obj.qty+" WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_laundry_details Err>>"+e);
        }
        return result;
    }
     public Laundry_Details select_laundry_details(int id){
        Laundry_Details obj =null;
        try {
            String query="SELECT id,laundry_id,rate,qty FROM laundry_details WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               int laundry_id = rset.getInt("laundry_id");
               double rate = rset.getDouble("rate");
               int qty = rset.getInt("qty");
               obj = new Laundry_Details(id, laundry_id, rate, qty);
            }
        } catch (Exception e) {
            System.out.println("select_laundry_details Err>>"+e);
        }
        return obj;
    }

    public ArrayList<Laundry_Details> selectAll_laundry_details(){
        ArrayList<Laundry_Details> objList = new ArrayList<Laundry_Details>();
        try {
            String query="SELECT id,laundry_id,rate,qty FROM laundry_details ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               int laundry_id = rset.getInt("laundry_id");
               double rate = rset.getDouble("rate");
               int qty = rset.getInt("qty");
               Laundry_Details obj = new Laundry_Details(id, laundry_id, rate, qty);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_laundry_details Err>>"+e);
        }
        return objList;
    }
   public ArrayList<Laundry_Details> selectAll_laundry_details(int laundry_id){
        ArrayList<Laundry_Details> objList = new ArrayList<Laundry_Details>();
        try {
            String query="SELECT id,laundry_id,rate,qty FROM laundry_details WHERE laundry_id="+laundry_id;
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               laundry_id = rset.getInt("laundry_id");
               double rate = rset.getDouble("rate");
               int qty = rset.getInt("qty");
               Laundry_Details obj = new Laundry_Details(id, laundry_id, rate, qty);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_laundry_details Err>>"+e);
        }
        return objList;
    }
    
    /******************************************************************/
     /******************************************************************/
    /*
        laundry_order,id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt
    */
    public int getMaxID_laundry_order(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM laundry_order";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxID_laundry_order Err>>"+e);
        }
        return mid;
    }

    public int insert_laundry_order(Laundry_Order obj){
        int result =0;
        try {
            String query="INSERT INTO laundry_order(id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt) VALUES("+obj.id+","+obj.user_id+",'"+obj.pickup_dt+"','"+obj.pickup_tm+"','"+obj.delivery_dt+"','"+obj.delivery_tm+"','"+obj.addr+"','"+obj.lat+"','"+obj.lng+"','"+obj.remark+"','"+obj.status+"','"+obj.dt+"')";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("insert_laundry_order Err>>"+e);
        }
        return result;
    }
    public int delete_laundry_order(int id){
        int result = 0;
        try {
            String query="DELETE FROM laundry_order WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("delete_laundry_order Err>>"+e);
        }
        return result;
    }
    
    public int update_laundry_order(Laundry_Order obj){
        int result =0;
        try {
            String query="UPDATE laundry_order SET user_id="+obj.user_id+",pickup_dt='"+obj.pickup_dt+"',pickup_tm='"+obj.pickup_tm+"',delivery_dt='"+obj.delivery_dt+"',delivery_tm='"+obj.delivery_tm+"',addr='"+obj.addr+"',lat='"+obj.lat+"',lng='"+obj.lng+"',remark='"+obj.remark+"',status='"+obj.status+"',dt='"+obj.dt+"' WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_laundry_order Err>>"+e);
        }
        return result;
    }
     public Laundry_Order select_laundry_order(int id){
        Laundry_Order obj =null;
        try {
            String query="SELECT id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt FROM laundry_order WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               int user_id = rset.getInt("user_id");
               String  pickup_dt = rset.getString("pickup_dt");
               String pickup_tm = rset.getString("pickup_tm");
               String delivery_dt = rset.getString("delivery_dt");
               String delivery_tm = rset.getString("delivery_tm");
               String addr = rset.getString("addr");
               String lat = rset.getString("lat");
               String lng = rset.getString("lng");
               String remark = rset.getString("remark");
               String status = rset.getString("status");
               String dt = rset.getString("dt");
               
               obj = new Laundry_Order(id, user_id, pickup_dt, pickup_tm, delivery_dt, delivery_tm, addr, lat, lng, remark, status, dt);
            }
        } catch (Exception e) {
            System.out.println("select_laundry_order Err>>"+e);
        }
        return obj;
    }

    public ArrayList<Laundry_Order> selectAll_laundry_order(){
        ArrayList<Laundry_Order> objList = new ArrayList<Laundry_Order>();
        try {
            String query="SELECT id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt FROM laundry_order ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               int user_id = rset.getInt("user_id");
               String  pickup_dt = rset.getString("pickup_dt");
               String pickup_tm = rset.getString("pickup_tm");
               String delivery_dt = rset.getString("delivery_dt");
               String delivery_tm = rset.getString("delivery_tm");
               String addr = rset.getString("addr");
               String lat = rset.getString("lat");
               String lng = rset.getString("lng");
               String remark = rset.getString("remark");
               String status = rset.getString("status");
               String dt = rset.getString("dt");
               
               Laundry_Order obj = new Laundry_Order(id, user_id, pickup_dt, pickup_tm, delivery_dt, delivery_tm, addr, lat, lng, remark, status, dt);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_laundry_order Err>>"+e);
        }
        return objList;
    }
   public ArrayList<Laundry_Order> selectAll_laundry_order(String status){
        ArrayList<Laundry_Order> objList = new ArrayList<Laundry_Order>();
        try {
            String query="SELECT id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt FROM laundry_order WHERE status='"+status+"'";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               int user_id = rset.getInt("user_id");
               String  pickup_dt = rset.getString("pickup_dt");
               String pickup_tm = rset.getString("pickup_tm");
               String delivery_dt = rset.getString("delivery_dt");
               String delivery_tm = rset.getString("delivery_tm");
               String addr = rset.getString("addr");
               String lat = rset.getString("lat");
               String lng = rset.getString("lng");
               String remark = rset.getString("remark");
               status = rset.getString("status");
               String dt = rset.getString("dt");
               
               Laundry_Order obj = new Laundry_Order(id, user_id, pickup_dt, pickup_tm, delivery_dt, delivery_tm, addr, lat, lng, remark, status, dt);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_laundry_order Err>>"+e);
        }
        return objList;
    }
   public ArrayList<Laundry_Order> selectAll_laundry_order(int user_id){
        ArrayList<Laundry_Order> objList = new ArrayList<Laundry_Order>();
        try {
            String query="SELECT id,user_id,pickup_dt,pickup_tm,delivery_dt,delivery_tm,addr,lat,lng,remark,status,dt FROM laundry_order WHERE user_id="+user_id;
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               user_id = rset.getInt("user_id");
               String  pickup_dt = rset.getString("pickup_dt");
               String pickup_tm = rset.getString("pickup_tm");
               String delivery_dt = rset.getString("delivery_dt");
               String delivery_tm = rset.getString("delivery_tm");
               String addr = rset.getString("addr");
               String lat = rset.getString("lat");
               String lng = rset.getString("lng");
               String remark = rset.getString("remark");
               String status = rset.getString("status");
               String dt = rset.getString("dt");
               
               Laundry_Order obj = new Laundry_Order(id, user_id, pickup_dt, pickup_tm, delivery_dt, delivery_tm, addr, lat, lng, remark, status, dt);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_laundry_order Err>>"+e);
        }
        return objList;
    }
    
    /******************************************************************/
     /******************************************************************/
     /*
    rate_settings,id,name,rate
    */
    public int getMaxID_rate_settings(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM rate_settings";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxID_rate_settings Err>>"+e);
        }
        return mid;
    }

    public int insert_rate_settings(Rate_Settings obj){
        int result =0;
        try {
            String query="INSERT INTO rate_settings(id,name,rate) VALUES("+obj.id+",'"+obj.name+"',"+obj.rate+")";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("insert_rate_settings Err>>"+e);
        }
        return result;
    }
    public int delete_rate_settings(int id){
        int result = 0;
        try {
            String query="DELETE FROM rate_settings WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("delete_rate_settings Err>>"+e);
        }
        return result;
    }
    
    public int update_rate_settings(Rate_Settings obj){
        int result =0;
        try {
            String query="UPDATE rate_settings SET name='"+obj.name+"',rate="+obj.rate+" WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_rate_settings Err>>"+e);
        }
        return result;
    }
     public Rate_Settings select_rate_settings(int id){
        Rate_Settings obj =null;
        try {
            String query="SELECT id,name,rate FROM rate_settings WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               String name = rset.getString("name");
               double rate = rset.getDouble("rate");
               
               obj = new Rate_Settings(id, name, rate);
               
            }
        } catch (Exception e) {
            System.out.println("select_rate_settings Err>>"+e);
        }
        return obj;
    }

    public ArrayList<Rate_Settings> selectAll_rate_settings(){
        ArrayList<Rate_Settings> objList = new ArrayList<Rate_Settings>();
        try {
            String query="SELECT id,name,rate FROM rate_settings ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               String name = rset.getString("name");
               double rate = rset.getDouble("rate");
               
               Rate_Settings obj = new Rate_Settings(id, name, rate);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_rate_settings Err>>"+e);
        }
        return objList;
    }
   
    
    /******************************************************************/
     /******************************************************************/
    /*
    user_details,id,name,mobile,email,dt,status
    */
    public int getMaxID_user_details(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM user_details";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return mid;
    }

    public int insert_user_details(User_Details obj){
        int result =0;
        try {
            String query="INSERT INTO user_details(id,name,mobile,email,dt,status) VALUES("+obj.id+",'"+obj.name+"','"+obj.mobile+"','"+obj.email+"','"+obj.dt+"','"+obj.status+"')";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return result;
    }
    public int delete_user_details(int id){
        int result = 0;
        try {
            String query="DELETE FROM user_details WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return result;
    }
    
    public int update_user_details(User_Details obj){
        int result =0;
        try {
            String query="UPDATE user_details SET name='"+obj.name+"',mobile='"+obj.mobile+"',email='"+obj.email+"',dt='"+obj.dt+"',status='"+obj.status+"' WHERE id="+obj.id;
            result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return result;
    }
     public User_Details select_user_details(int id){
        User_Details obj =null;
        try {
            String query="SELECT id,name,mobile,email,dt,status FROM user_details WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               String name = rset.getString("name");
               String mobile  = rset.getString("mobile");
               String email  = rset.getString("email");
               String dt  = rset.getString("dt");
               String status = rset.getString("status");
               obj = new User_Details(id, name, mobile, email, dt, status);
            }
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return obj;
    }

    public ArrayList<User_Details> selectAll_user_details(){
        ArrayList<User_Details> objList = new ArrayList<User_Details>();
        try {
            String query="SELECT id,name,mobile,email,dt,status FROM user_details ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               String name = rset.getString("name");
               String mobile  = rset.getString("mobile");
               String email  = rset.getString("email");
               String dt  = rset.getString("dt");
               String status = rset.getString("status");
               User_Details obj = new User_Details(id, name, mobile, email, dt, status);
            }
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return objList;
    }
   
    
    /******************************************************************/
     /******************************************************************/
    /*
     user_login,id,uname,passwd
    */
    public int getMaxID_user_login(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM user_login";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxID_user_login Err>>"+e);
        }
        return mid;
    }

    public int insert_user_login(User_Login obj){
        int result =0;
        try {
            String query="INSERT INTO user_login(id,uname,passwd) VALUES("+obj.id+",'"+obj.uname+"','"+obj.passwd+"')";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("insert_user_login Err>>"+e);
        }
        return result;
    }
    public int delete_user_login(int id){
        int result = 0;
        try {
            String query="DELETE FROM user_login WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("delete_user_login Err>>"+e);
        }
        return result;
    }
    
    public int update_user_login(User_Login obj){
        int result =0;
        try {
            String query="UPDATE user_login SET uname='"+obj.uname+"',passwd='"+obj.passwd+"' WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_user_login Err>>"+e);
        }
        return result;
    }
    public int update_user_login(String uname,String opasswd,String npasswd){
        int result =0;
        try {
            String query="UPDATE user_login SET passwd='"+npasswd+"' WHERE uname='"+uname+"' AND passwd='"+opasswd+"'";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_user_login Err>>"+e);
        }
        return result;
    }
     public User_Login select_user_login(int id){
        User_Login obj =null;
        try {
            String query="SELECT id,uname,passwd FROM user_login WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               String uname = rset.getString("uname");
               String passwd = rset.getString("passwd");
               obj = new User_Login(id, uname, passwd);
               
               
            }
        } catch (Exception e) {
            System.out.println("select_user_login Err>>"+e);
        }
        return obj;
    }
    public User_Login select_user_login(String uname,String passwd){
        User_Login obj =null;
        try {
            String query="SELECT id,uname,passwd FROM user_login WHERE uname='"+uname+"' AND passwd='"+passwd+"'";
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               int id = rset.getInt("id");
               uname = rset.getString("uname");
               passwd = rset.getString("passwd");
               obj = new User_Login(id, uname, passwd);
               
               
            }
        } catch (Exception e) {
            System.out.println("select_user_login Err>>"+e);
        }
        return obj;
    }
    public ArrayList<User_Login> selectAll_user_login(){
        ArrayList<User_Login> objList = new ArrayList<User_Login>();
        try {
            String query="SELECT id,uname,passwd FROM user_login ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               String uname = rset.getString("uname");
               String passwd = rset.getString("passwd");
               User_Login obj = new User_Login(id, uname, passwd);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_user_login Err>>"+e);
        }
        return objList;
    }
   
    
    /******************************************************************/
     /******************************************************************/
    /*
    payment_details,id,user_id,laundry_id,typ,amt,dt
    */
    public int getMaxID_payment_details(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM payment_details";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("getMaxID_payment_details Err>>"+e);
        }
        return mid;
    }

    public int insert_payment_details(Payment_Details obj){
        int result =0;
        try {
            String query="INSERT INTO payment_details(id,user_id,laundry_id,typ,amt,dt) VALUES("+obj.id+","+obj.user_id+","+obj.laundry_id+",'"+obj.typ+"',"+obj.amt+",'"+obj.dt+"')";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("insert_payment_details Err>>"+e);
        }
        return result;
    }
    public int delete_payment_details(int id){
        int result = 0;
        try {
            String query="DELETE FROM payment_details WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("delete_payment_details Err>>"+e);
        }
        return result;
    }
    
    public int update_payment_details(Payment_Details obj){
        int result =0;
        try {
            String query="UPDATE payment_details SET user_id="+obj.user_id+",laundry_id="+obj.laundry_id+",typ='"+obj.typ+"',amt="+obj.amt+",dt='"+obj.dt+"' WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println("update_payment_details Err>>"+e);
        }
        return result;
    }
     public Payment_Details select_payment_details(int id){
        Payment_Details obj =null;
        try {
            String query="SELECT id,user_id,laundry_id,typ,amt,dt FROM payment_details WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               id = rset.getInt("id");
               int user_id = rset.getInt("user_id");
               int laundry_id = rset.getInt("laundry_id");
               String typ = rset.getString("typ");
               double amt = rset.getDouble("amt");
               String dt = rset.getString("dt");
               
               obj = new Payment_Details(id, user_id, laundry_id, typ, amt, dt);
            }
        } catch (Exception e) {
            System.out.println("select_payment_details Err>>"+e);
        }
        return obj;
    }

    public ArrayList<Payment_Details> selectAll_payment_details(){
        ArrayList<Payment_Details> objList = new ArrayList<Payment_Details>();
        try {
            String query="SELECT id,user_id,laundry_id,typ,amt,dt FROM payment_details ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               int user_id = rset.getInt("user_id");
               int laundry_id = rset.getInt("laundry_id");
               String typ = rset.getString("typ");
               double amt = rset.getDouble("amt");
               String dt = rset.getString("dt");
               
               Payment_Details obj = new Payment_Details(id, user_id, laundry_id, typ, amt, dt);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_payment_details Err>>"+e);
        }
        return objList;
    }
   public ArrayList<Payment_Details> selectAll_payment_details(int user_id){
        ArrayList<Payment_Details> objList = new ArrayList<Payment_Details>();
        try {
            String query="SELECT id,user_id,laundry_id,typ,amt,dt FROM payment_details WHERE user_id="+user_id;
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               int id = rset.getInt("id");
               user_id = rset.getInt("user_id");
               int laundry_id = rset.getInt("laundry_id");
               String typ = rset.getString("typ");
               double amt = rset.getDouble("amt");
               String dt = rset.getString("dt");
               
               Payment_Details obj = new Payment_Details(id, user_id, laundry_id, typ, amt, dt);
               objList.add(obj);
            }
        } catch (Exception e) {
            System.out.println("selectAll_payment_details Err>>"+e);
        }
        return objList;
    }
    
    /******************************************************************/
     /******************************************************************
    public int getMaxID_(){
        int mid =0;
        try {
            String query="SELECT MAX(id) FROM **";
             ResultSet rset = executeQuery(query);
            if(rset.next()){
                mid = rset.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return mid;
    }

    public int insert_(Object obj){
        int result =0;
        try {
            String query="INSERT INTO **() VALUES()";
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return result;
    }
    public int delete_(int id){
        int result = 0;
        try {
            String query="DELETE FROM ** WHERE id="+id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return result;
    }
    
    public int update_(Object obj){
        int result =0;
        try {
            String query="UPDATE ** SET ** WHERE id="+obj.id;
             result = executeUpdate(query);
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return result;
    }
     public Object select_(int id){
        Object obj =null;
        try {
            String query="SELECT ** FROM ** WHERE id="+id;
            ResultSet rset = executeQuery(query);
            if(rset.next()){
               
            }
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return obj;
    }

    public ArrayList<Object> selectAll_(){
        ArrayList<Object> objList = new ArrayList<Object>();
        try {
            String query="SELECT ** FROM ** ";
            ResultSet rset = executeQuery(query);
            while(rset.next()){
               
            }
        } catch (Exception e) {
            System.out.println(" Err>>"+e);
        }
        return objList;
    }
   
    
    /******************************************************************/
    
}
