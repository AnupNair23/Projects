/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package util;

/**
 *
 * @author sarath
 */
public class Variables {
    public  static double[] lons =new double[]{76.25962,76.9411119,76.9898268,76.25953982428568 };
    public static double[] lats = new double[]{10.095388333333334,8.525103,8.5096978,10.095693778464856};
}
